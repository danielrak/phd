# agecfhfee_pcs_g2 (def2). 
  # fee : effets école.
  # intérêt : trouver une explication à l'effet 
    # plus fort chez les très favorisés. 

library(here)
library(tidyverse)
library(plm)
library(lmtest)
library(stringi)

# Chargement --------------------------------------------------------------

load("D:/00_phd/00_fonctions/fonctions.rda")
load(here("01_donnees_def.rda"))
load(here("agepe_def2", "agepefee.rda"))
source(here("agedepvars.R"))

# Sur c -------------------------------------------------------------------

for (i in agedepvars_c %>% 
     (function (a) a[str_detect(a, "_norm")])) {
  assign(paste("agecfhfee_pcs_g2_", 
               i, 
               "_tous_c",
               sep = ""),
         plm(as.formula(paste(
           i, " ~ ", 
           c("age_abs", "age_abs : pcs_g2",
             
             "resid", "resid : age_abs", 
             "resid : pcs_g2", "resid : age_abs : pcs_g2",
             
             "pcs_g2", "sexe", "cohorte") %>% 
             paste(collapse = " + "),
           sep = ""
         )),
         c %>% arrange(ecolecoh) %>% 
           mutate(resid = resid.agepefee_z_tous_c),
         index = "ecolecoh"))
}

# Inférence et narsq ------------------------------------------------------

for (i in ls()[str_detect(ls(), "^agecfh")]) {
  assign(paste("ct.", i, sep = ""),
         rsearellano(get(i)))
  assign(paste("n.", i, sep = ""), nobs(get(i)))
  assign(paste("arsq.", i, sep = ""), ext_adjrsq(get(i)))
}

# Sauvegarde --------------------------------------------------------------

save(list = ls()[str_detect(ls(), "agecfh") & 
                   ! str_detect(ls(), "^agecfh")],
     file = here("agecfh_def2", "agecfhfee_pcs_g2.rda"),
     version = 2)